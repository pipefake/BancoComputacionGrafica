/**
* Crea una copia segura …
* @author Jonathan.rojas@uao.edu.co Jonathan Rojas Ibanez 2190039
* @author andrea.perez@uao.edu.co Andrea Perez 2190936
* @author juan_felipe.jimenez@uao.edu.co Juan Felipe Jimenez Salazar 2190038
* @date 03 Septiembre 2020si
* @version 1.0
*/
package core;



/**
 *
 * @author Universidad Felipe
 */
public abstract class Base {
    public abstract Base copy();
}
